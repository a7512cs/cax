﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NXOpen;
using NXOpen.UF;
using CimforceCaxTwCNC;
using CimforceCaxTwFixture;
using LicenseCheck;
using CimforceCaxTwPublic;
using System.IO;
using DevComponents.DotNetBar;
using NXOpen.CAM;
using NXOpen.Annotations;

namespace ETableWork
{
    class Class001_ETableInit
    {
        //↓↓↓↓↓↓↓↓↓↓宣告所有參數↓↓↓↓↓↓↓↓↓↓//
        private static Session theSession;
        private static UI theUI;
        private static UFSession theUfSession;
        private static Part displayPart;

//         private const string SUPPORT_MACHINE = "";
//         private const string MACHINE_TYPE = "";
//         private const string CONTROLLER = "";

        public string asmName;                  // 檔案名稱
        public string rootPath;                 // 檔案路徑
        public string postFunctionName;         // 可用的Post名稱
        public string section_face;             // 裝夾圖圖紙名稱
        public string baseHoleName;             // 放電基準孔圖紙名稱
        public string beforeCNCName;            // 加工前檢測圖圖紙名稱
        public string afterCNCName;             // 加工後檢測圖圖紙名稱
        public string fixture_type;             // 治具類型

        // 讀取資料
        public ToolCuttingLength cToolCuttingLength;
        public MesAttrCNC sMesDatData;
        public ConfigData config;

        // 組立架構
        public List<CaxAsm.CompPart> AsmCompAry;
        public CaxAsm.CimAsmCompPart sCimAsmCompPart;
        public double[] minDesignBodyWcs;
        public double[] maxDesignBodyWcs;
        public List<CaxPart.BaseCorner> baseCornerAry;
        public List<CaxAsm.CompPart> fixtureLst;
        public List<NXOpen.Assemblies.Component> subDesignCompLst;

        public bool hasMultiFixture;
        public bool isMultiFixture;
        public bool isASM;
        // operation...
        public List<ListToolLengeh> ListToolLengehAry;
        // 一些距離...
        public ExportWorkTabel sExportWorkTabel;
        // 電極件號
        public BaseNote elecPartNoNote;


        //↑↑↑↑↑↑↑↑↑↑宣告所有參數↑↑↑↑↑↑↑↑↑↑//
        // 參數初始化
        public Class001_ETableInit()
        {
            theSession = Session.GetSession();
            theUI = UI.GetUI();
            theUfSession = UFSession.GetUFSession();
            displayPart = theSession.Parts.Display;

            asmName = "";
            rootPath = "";
            postFunctionName = "";
            baseHoleName = "";
            beforeCNCName = "";
            afterCNCName = "";
            fixture_type = "";

            cToolCuttingLength = new ToolCuttingLength();
            sMesDatData = new MesAttrCNC();
            config = new ConfigData();

            AsmCompAry = new List<CaxAsm.CompPart>();
            sCimAsmCompPart = new CaxAsm.CimAsmCompPart();
            baseCornerAry = new List<CaxPart.BaseCorner>();
            fixtureLst = new List<CaxAsm.CompPart>();
            subDesignCompLst = new List<NXOpen.Assemblies.Component>();

            hasMultiFixture = false;
            isMultiFixture = false;
            isASM = false;

            ListToolLengehAry = new List<ListToolLengeh>();
            sExportWorkTabel = new ExportWorkTabel();
            elecPartNoNote = null;
        }


        public bool GetAllParameter()
        {
            bool status;
            int errorNum;
            // 開啟讀取對話框
            CaxLoadingDlg sCaxLoadingDlg = null;
            sCaxLoadingDlg = new CaxLoadingDlg();
            try
            {
                // 確認啟動環境
                errorNum = ConfirmAllEnv();
                if (errorNum < 0)
                {
                    if (errorNum != -1)
                    {
                        CaxLog.ShowListingWindow("確認啟動環境時發生未知錯誤...");
                    }
                    sCaxLoadingDlg.Stop();
                    return false;
                }

                // 取得檔案名稱、路徑
                theUfSession.Part.AskPartName(displayPart.Tag, out asmName);
                rootPath = Path.GetDirectoryName(asmName);

                // 讀取資料
                errorNum = GetAllStructs();
                if (errorNum < 0)
                {
                    if (errorNum != -1)
                    {
                        CaxLog.ShowListingWindow("讀取資料時發生未知錯誤...");
                    }
                    sCaxLoadingDlg.Stop();
                    return false;
                }

                // 確認確認是否有建立裝夾圖 (DEPO多三張圖)
                errorNum = ConfirmSheets();
                if (errorNum < 0)
                {
                    if (errorNum != -1)
                    {
                        CaxLog.ShowListingWindow("圖紙確認時發生未知錯誤...");
                    }
                    sCaxLoadingDlg.Stop();
                    return false;
                }

                // 4. 取得組立架構
                errorNum = GetComponentTree();
                if (errorNum < 0)
                {
                    if (errorNum != -1)
                    {
                        CaxLog.ShowListingWindow("取得組立架構時發生未知錯誤...");
                    }
                    sCaxLoadingDlg.Stop();
                    return false;
                }

                // 取得設計零件檔資訊
                errorNum = GetLayerBodyData();
                if (errorNum < 0)
                {
                    if (errorNum != -1)
                    {
                        CaxLog.ShowListingWindow("取得設計零件檔資訊時發生未知錯誤...");
                    }
                    sCaxLoadingDlg.Stop();
                    return false;
                }

                // 取得治具類型，判斷是否有多治具功能、是否為多治具
                errorNum = GetFixtureData();
                if (errorNum < 0)
                {
                    if (errorNum != -1)
                    {
                        CaxLog.ShowListingWindow("取得治具資料時發生未知錯誤...");
                    }
                    sCaxLoadingDlg.Stop();
                    return false;
                }

                // 判斷是否為組立加工，是則找出所有次主件
                status = DetermineASM();
                if (!status)
                {
                    sCaxLoadingDlg.Stop();
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "判斷是否為組立加工時發生未知錯誤...");
                    return false;
                }

                //1.取得opration的名稱陣列 
                //2.取得最大切削長度
                //3.取得part offset (Gap)
                status = GetOperationData();
                if (!status)
                {
                    sCaxLoadingDlg.Stop();
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "刀具路徑資訊取得錯誤...");
                    return false;
                }

                //1.取得工件T面轉BO面Z軸偏移的距離
                //2.基準角底面到座標原點的距離
                //3.基準角長面(距離原點較長的面)到座標原點的距離
                //4.基準角短面(距離原點較短的面)到座標原點的距離
                status = GetCsysToRefFaceData();
                if (!status)
                {
                    sCaxLoadingDlg.Stop();
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "取得偏移距離錯誤...");
                    return false;
                }

                // 取得電極件號的Note
                status = GetElecPartNoNote();
                if (!status)
                {
                    sCaxLoadingDlg.Stop();
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "取得電極件號錯誤...");
                    return false;
                }

                // 關閉讀取對話框
                sCaxLoadingDlg.Stop();
            }
            catch (System.Exception ex)
            {
                sCaxLoadingDlg.Stop();
                return false;
            }
            return true;

        }

        private int ConfirmAllEnv()
        {
            try
            {
                //確認啟動環境
                string license_status = "";
                license_status = License.ChkCimforceLicense();
                if (license_status != "CIMFORCE_LICENSE_SUCCESS")
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "License 錯誤!");
                    return -1;
                }

                Part displayPrt = theSession.Parts.Display;
                if (displayPrt == null)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "ERROR,未開啟零件.");
                    return -1;
                }

                int module_id;
                theUfSession.UF.AskApplicationModule(out module_id);
                if (module_id != UFConstants.UF_APP_CAM)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Information, "請先切換至 CAM 模組");
                    return -1;
                }
            }
            catch (System.Exception ex)
            {
                return -1001;
            }
            return 0;
        }

        private int GetAllStructs()
        {
            bool status;
            try
            {
                //取得mes2cam.dat路徑
                string mes2camDatPath = CaxCNC.GetMes2CamDatPath(displayPart);
                if (mes2camDatPath == "")
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Information, "mes2cam.dat 讀取失敗");
                    return -1;
                }
                //取得mes2cam.dat資料
                if (!CaxCNC.ReadMesAttrCNCJsonData(mes2camDatPath, out sMesDatData))
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, mes2camDatPath + " 讀取失敗!");
                    return -1;
                }

                //取得刀具最大切削壽命(結構)
                status = CaxCNC.ReadToolCuttingLengthCNCJsonData(out cToolCuttingLength);
                if (!status || cToolCuttingLength == null)
                {
                    CaxLog.ShowListingWindow("MES 刀具壽命配置檔讀取失敗...");
                    return -1;
                }

                // 讀取配置檔(ETableConfig.txt)
                string JsonConfigFilePath = string.Format(@"{0}\Cimforce\CNC\config\{1}", CaxFile.GetCimforceEnvDir(), "ETableConfig.txt");
                status = ReadJsonData(JsonConfigFilePath, out config);
                if (!status)
                {
                    CaxLog.ShowListingWindow("讀取配置檔ETableConfig.txt時發生錯誤");
                    return -1;
                }

                //2014/04/09 新增機台類型對應POST↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓小伍提出修改
                //取得所有可用的Post名稱
                int count;
                string[] PostNames;
                theUfSession.Cam.OptAskPostNames(out count, out PostNames);

                postFunctionName = sMesDatData.MAC_POST_NM;
                if (postFunctionName == "")
                {
                    CaxLog.ShowListingWindow("機台類型對應的POST讀取錯誤...");
                    return -1;
                }

                for (int i = 0; i < PostNames.Length; i++)
                {
                    if (PostNames[i].ToUpper() == sMesDatData.MAC_POST_NM.ToUpper())
                    {
                        postFunctionName = PostNames[i];
                        break;
                    }
                }
                //2014/04/09 新增機台類型對應POST↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑小伍提出修改
            }
            catch (System.Exception ex)
            {
                return -1001;
            }
            return 0;
        }

        private int ConfirmSheets()
        {
            try
            {
                // DEPO
                if (config.companyName.ToUpper() == "DEPO")
                {
                    section_face = string.Format(@"{0}_{1}", sMesDatData.SECTION_ID, sMesDatData.FACE_TYPE_ID);
                    baseHoleName = string.Format(@"{0}_{1}_{2}", sMesDatData.SECTION_ID, sMesDatData.FACE_TYPE_ID, "BaseHole");
                    beforeCNCName = string.Format(@"{0}_{1}_{2}", sMesDatData.SECTION_ID, sMesDatData.FACE_TYPE_ID, "BeforeCNC");
                    afterCNCName = string.Format(@"{0}_{1}_{2}", sMesDatData.SECTION_ID, sMesDatData.FACE_TYPE_ID, "AfterCNC");
                    int drawingNum = 0;
                    string drawingName = "";
                    Tag[] drawings;
                    bool chk_drafting_name = false;
                    bool chk_baseHole_name = false;
                    bool chk_beforeCNC_name = false;
                    bool chk_afterCNC_name = false;
                    theUfSession.Draw.AskDrawings(out drawingNum, out drawings);
                    for (int i = 0; i < drawingNum; i++)
                    {
                        theUfSession.Obj.AskName(drawings[i], out drawingName);
                        if (drawingName.ToUpper() == section_face.ToUpper())
                        {
                            chk_drafting_name = true;
                        }
                        if (drawingName.ToUpper() == baseHoleName.ToUpper())
                        {
                            chk_baseHole_name = true;
                        }
                        if (drawingName.ToUpper() == beforeCNCName.ToUpper())
                        {
                            chk_beforeCNC_name = true;
                        }
                        if (drawingName.ToUpper() == afterCNCName.ToUpper())
                        {
                            chk_afterCNC_name = true;
                        }
                    }
                    if (!chk_drafting_name)
                    {
                        UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "ERROR,尚未建立 " + section_face + " 裝夾圖");
                        return -1;
                    }
                    // 模仁才檢查這三張圖
                    if (sMesDatData.PART_TYPE_ID == "0" || sMesDatData.PART_TYPE_ID == "4")
                    {
                        if (!chk_baseHole_name)
                        {
                            string dialogText = string.Format("電極基準孔圖尚未建立，是否仍要出電子工單？");
                            eTaskDialogResult result = CaxMsg.ShowMsgYesNo(dialogText, eTaskDialogIcon.Help, "電極基準孔圖尚未建立");
                            if (result == eTaskDialogResult.Yes)
                            {
                                baseHoleName = "";
                            }
                            if (result == eTaskDialogResult.No)
                            {
                                return -1;
                            }
                        }
                        if (!chk_beforeCNC_name)
                        {
                            string dialogText = string.Format("加工前檢測圖尚未建立，是否仍要出電子工單？");
                            eTaskDialogResult result = CaxMsg.ShowMsgYesNo(dialogText, eTaskDialogIcon.Help, "加工前檢測圖尚未建立");
                            if (result == eTaskDialogResult.Yes)
                            {
                                beforeCNCName = "";
                            }
                            if (result == eTaskDialogResult.No)
                            {
                                return -1;
                            }
                        }
                        if (!chk_afterCNC_name)
                        {
                            string dialogText = string.Format("加工後檢測圖尚未建立，是否仍要出電子工單？");
                            eTaskDialogResult result = CaxMsg.ShowMsgYesNo(dialogText, eTaskDialogIcon.Help, "加工後檢測圖尚未建立");
                            if (result == eTaskDialogResult.Yes)
                            {
                                afterCNCName = "";
                            }
                            if (result == eTaskDialogResult.No)
                            {
                                return -1;
                            }
                        }
                    }
                    else
                    {
                        baseHoleName = "";
                        beforeCNCName = "";
                        afterCNCName = "";
                    }
                }
                else if (config.companyName.ToUpper() == "COXON")
                {
                    //確認是否有建立裝夾圖 2014/01/06
                    section_face = string.Format(@"{0}_{1}", sMesDatData.SECTION_ID, sMesDatData.FACE_TYPE_ID);
                    int drawingNum = 0;
                    string drawingNam = "";
                    Tag[] drawings;
                    bool chk_drawing_name = false;
                    theUfSession.Draw.AskDrawings(out drawingNum, out drawings);
                    for (int i = 0; i < drawingNum; i++)
                    {
                        theUfSession.Obj.AskName(drawings[i], out drawingNam);
                        if (drawingNam.ToUpper() == section_face.ToUpper())
                        {
                            chk_drawing_name = true;
                        }
                    }
                    if (!chk_drawing_name)
                    {
                        UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "ERROR,尚未建立 " + section_face + " 裝夾圖");
                        return -1;
                    }
                }
            }
            catch (System.Exception ex)
            {
                return -1001;
            }
            return 0;
        }

        private int GetComponentTree()
        {
            bool status;
            try
            {
                //取得組立架構
                int err;
                err = CaxAsm.GetAsmCompTree(out AsmCompAry);
                if (err != 0)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "組立架構讀取失敗...");
                    return -1;
                }
                status = CaxAsm.GetCimAsmCompStruct(AsmCompAry, out sCimAsmCompPart);
                if (!status)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "組立架構讀取失敗...");
                    return -1;
                }
                if (sCimAsmCompPart.design.comp == null)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "設計零件讀取失敗...");
                    return -1;
                }
                if (sCimAsmCompPart.fixture.comp == null)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "治具零件讀取失敗...");
                    return -1;
                }
                if (sCimAsmCompPart.blank.comp == null)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "請先建立blank...");
                    return -1;
                }
            }
            catch (System.Exception ex)
            {
                return -1001;
            }
            return 0;
        }

        private int GetLayerBodyData()
        {
            bool status;
            try
            {
                // 取得設計零件的LayerBody
                Body designBody = null;
                status = CaxPart.GetLayerBody(sCimAsmCompPart.design.part, out designBody);
                if (!status)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "設計零件的LayerBody讀取失敗...");
                    return -1;
                }
                // 取得設計零件的尺寸大小
                Body designBodyOcc = null;
                CaxTransType.BodyPrototypeToNXOpenOcc(sCimAsmCompPart.design.comp.Tag, designBody.Tag, out designBodyOcc);
                CaxPart.AskBoundingBoxExactByWCS(designBodyOcc.Tag, out minDesignBodyWcs, out maxDesignBodyWcs);

                // 取得設計零件的基準面
                status = CaxPart.GetBaseCornerFaceAry(sCimAsmCompPart.design.comp, out baseCornerAry);
                if (!status)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "基準角取得錯誤...");
                    return -1;
                }

                // 判斷是否建立Blank素材檔
                if (sCimAsmCompPart.blank.comp == null)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "請先建立Blank素材檔...");
                    return -1;
                }

            }
            catch (System.Exception ex)
            {
                return -1001;
            }
            return 0;
        }

        private int GetFixtureData()
        {
            try
            {
                //取得治具類型
                string attr_value = "";
                // 判斷是否有多治具功能
                hasMultiFixture = (config.hasMultiFixture == "1");
                if (hasMultiFixture)
                {
                    // 有多治具功能
                    int fixtureNo = 0;
                    foreach (CaxAsm.CompPart compPart in AsmCompAry)
                    {
                        try
                        {
                            string attr = compPart.componentOcc.GetStringAttribute(CaxDefineParam.ATTR_CIM_TYPE);
                            if (attr == "FIXTURE")
                            {
                                fixtureLst.Add(compPart);
                                fixtureNo++;
                            }
                        }
                        catch (System.Exception ex)
                        {
                            attr_value = "";
                            continue;
                        }
                    }
                    if (fixtureNo > 1)
                    {
                        isMultiFixture = true;
                        attr_value = "多治具";
                    }
                    else
                    {
                        isMultiFixture = false;
                        try
                        {
                            attr_value = sCimAsmCompPart.fixture.comp.GetStringAttribute("FIXTURE_TYPE");
                        }
                        catch (System.Exception ex)
                        {
                            attr_value = "";
                        }
                    }
                }
                else
                {
                    // 沒有多治具功能
                    try
                    {
                        attr_value = sCimAsmCompPart.fixture.comp.GetStringAttribute("FIXTURE_TYPE");
                    }
                    catch (System.Exception ex)
                    {
                        attr_value = "";
                    }
                }
                fixture_type = attr_value;

                if (fixture_type == "")
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "請先裝夾治具...");
                    return -1;
                }
            }
            catch (System.Exception ex)
            {
                return -1001;
            }
            return 0;
        }

        private bool DetermineASM()
        {
            try
            {
                if (sMesDatData.PROCESS_DESIGN == "ASM" || sMesDatData.PROCESS_DESIGN == "ASM_MODIFIED")
                {
                    isASM = true;
                    string attr_value = "";
                    foreach (CaxAsm.CompPart compPart in AsmCompAry)
                    {
                        try
                        {
                            attr_value = compPart.componentOcc.GetStringAttribute(CaxDefineParam.ATTR_CIM_TYPE);
                            if (attr_value == CaxDefineParam.ATTR_CIM_TYPE_SUB_DESIGN)
                            {
                                subDesignCompLst.Add(compPart.componentOcc);
                            }
                        }
                        catch (System.Exception ex)
                        {
                            attr_value = "";
                            continue;
                        }
                    }
                }

            }
            catch (System.Exception ex)
            {
                return false;
            }
            return true;
        }

        private bool GetOperationData()
        {
            try
            {
                //Issue #9630
                // 刀具壽命限制有份兩段
                // 1，單條operation超出刀具壽命
                // 2，同一把刀所有的operation超出刀具壽命
                //  之前因為捨棄式刀具沒有上，也沒有注意,CAX段把這兩個全限制了
                // 現在我在測試捨棄式刀具，就有發現問題，因為捨棄式刀具是可以更換刀片的，所以現在的需求需要改下
                // 
                // 當是整體式刀具，就按現在的規則（1和2都不要滿足）
                // 如果是捨棄式刀具，需要修改成
                // 1，單條OPERATION超出刀具壽命 這條還是不變
                // 2，同一把刀所有的OPERATION超出刀具壽命 這條不需要限制（也就是還是可以出工單）

                bool status;

                //取得opration的名稱陣列
                //ArrayList operationAry = new ArrayList();
                Part workPart = theSession.Parts.Work;
                Part dispPart = theSession.Parts.Display;
                //string workFace_name = "";

                try
                {
                    if (dispPart.CAMSetup == null)
                    {
                        UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "ERROR,請先建立Operation.");
                        return false;
                    }
                }
                catch (System.Exception ex)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "ERROR,請先建立Operation.");
                    return false;
                }

                //取得Operation Name
                OperationCollection Operations = dispPart.CAMSetup.CAMOperationCollection;
                Operation[] OperationAry = Operations.ToArray();
                if (OperationAry.Length == 0)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "ERROR,請先建立Operation.");
                    return false;
                }

                //判斷Program Order Group 名稱與工段是否相同 2014/01/06
                NCGroup operationGroup;
                bool chk_faca_name = false;
                double max_length = 0.0;
                List<ToolLengehStatus> toolStatusAry = new List<ToolLengehStatus>();

                ListToolLengeh sListToolLengeh;
                sListToolLengeh.oper = null;
                sListToolLengeh.isOK = false;
                sListToolLengeh.isOverToolLength = false;
                sListToolLengeh.tool_name = "";
                sListToolLengeh.tool_ext_length = "";
                sListToolLengeh.oper_name = "";
                sListToolLengeh.cutting_length = 0.0;
                sListToolLengeh.cutting_length_max = 0.0;
                sListToolLengeh.part_offset = 0.0;

                ToolLengehStatus sToolLengehStatus;
                sToolLengehStatus.tool_name = "";
                sToolLengehStatus.tool_ext_length = "";
                sToolLengehStatus.cutting_length_max = 0.0;

                //判斷是否為電極
                if (sMesDatData.PART_TYPE_ID == "5")
                {
                    //電極

                    for (int a = 0; a < sMesDatData.ED_PARTS.Count; a++)
                    {
                        for (int i = 0; i < OperationAry.Length; i++)
                        {
                            operationGroup = OperationAry[i].GetParent(CAMSetup.View.ProgramOrder);
                            //if (section_face.ToUpper() == operationGroup.Name.ToUpper())
                            //{
                            chk_faca_name = true;

                            /*
                            double gap = sMesDatData.ED_PARTS[a].DISCHARGE_GAP;
                            if (gap > 0)
                            {
                                gap = gap * (-1);
                            }

                            status = CaxCAM.SetPartOffset(gap, "WORKPIECE_EL_AREA");
                            if (!status)
                            {
                                UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, OperationAry[i].Name + " Part Offset 設定失敗...");
                                return false;
                            }
                            */

                            //Type operType = OperationAry[i].GetType();
                            //CaxLog.ShowListingWindow("OPERATION_TYPE : " + operType.Name.ToString());

                            //CaxLog.ShowListingWindow("GetStatus : " + OperationAry[i].GetStatus().ToString());
                            if (OperationAry[i].GetStatus() != CAMObject.Status.Complete && OperationAry[i].GetStatus() != CAMObject.Status.Repost)
                            {
                                status = CaxCAM.GenerateToolPath(OperationAry[i].Name);
                                if (!status)
                                {
                                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, OperationAry[i].Name + " Generate 失敗...");
                                    return false;
                                }
                            }

                            //CaxLog.ShowListingWindow("ToString : " + OperationAry[i].ToString());

                            //取得operation
                            sListToolLengeh.oper = OperationAry[i];

                            //取得operation名稱
                            sListToolLengeh.oper_name = OperationAry[i].Name;

                            //取得刀具GROUP
                            operationGroup = OperationAry[i].GetParent(CAMSetup.View.MachineTool);


                            //CaxLog.ShowListingWindow("TOOL_NAME : " + operationGroup.Name.ToString());

                            //GetToolData(operationGroup.Name);

                            //取得刀具名稱
                            string[] MachineToolNameSplitAry = operationGroup.Name.Split('_');
                            if (MachineToolNameSplitAry.Length < 3)
                            {
                                CaxLog.ShowListingWindow("刀具名稱錯誤 : " + operationGroup.Name);
                                return false;
                            }
                            sListToolLengeh.tool_name = MachineToolNameSplitAry[0];

                            sListToolLengeh.tool_ext_length = MachineToolNameSplitAry[2];

                            //取得切削長度
                            sListToolLengeh.cutting_length = OperationAry[i].GetToolpathCuttingLength();
                            //sListToolLengeh.cutting_length = 170000;

                            //取得part offset (Gap)
                            sListToolLengeh.part_offset = sMesDatData.ED_PARTS[a].DISCHARGE_GAP;
                            //CaxLog.ShowListingWindow(sMesDatData.ED_PARTS[a].DISCHARGE_GAP.ToString());

                            //判斷切削長度是否過長
                            max_length = 0.0;
                            sListToolLengeh.isOK = false;
                            sListToolLengeh.cutting_length_max = 0.0;
                            for (int j = 0; j < cToolCuttingLength.data.Count; j++)
                            {
                                if (cToolCuttingLength.data[j].TOOL_STD_ID.ToUpper() == sListToolLengeh.tool_name.ToUpper())
                                {
                                    for (int k = 0; k < cToolCuttingLength.data[j].HRC_ARRAY.Count; k++)
                                    {
                                        if (cToolCuttingLength.data[j].HRC_ARRAY[k].TOOL_METER > max_length)
                                        {
                                            max_length = cToolCuttingLength.data[j].HRC_ARRAY[k].TOOL_METER;
                                        }

                                        if ((cToolCuttingLength.data[j].HRC_ARRAY[k].TOOL_METER * 1000) > sListToolLengeh.cutting_length)
                                        {
                                            sListToolLengeh.isOK = true;
                                            goto GOTO_ISOK;
                                        }
                                    }
                                }
                            }

                        GOTO_ISOK:

                            //取得最大切削長度 (MES單位為m，所以要*1000 = mm)
                            sListToolLengeh.cutting_length_max = max_length * 1000;

                            bool chk_tool_name = false;
                            for (int j = 0; j < toolStatusAry.Count; j++)
                            {
                                if (sListToolLengeh.tool_name == toolStatusAry[j].tool_name)
                                {
                                    chk_tool_name = true;
                                }
                            }
                            if (!chk_tool_name)
                            {
                                //sToolLengehStatus.isOverToolLength = false;
                                sToolLengehStatus.tool_name = sListToolLengeh.tool_name;
                                sToolLengehStatus.tool_ext_length = sListToolLengeh.tool_ext_length;
                                sToolLengehStatus.cutting_length_max = sListToolLengeh.cutting_length_max;
                                toolStatusAry.Add(sToolLengehStatus);
                            }

                            ListToolLengehAry.Add(sListToolLengeh);
                            continue;
                            //}

                        }
                    }
                }
                else
                {
                    //非電極(工件)

                    for (int i = 0; i < OperationAry.Length; i++)
                    {
                        sListToolLengeh.oper = null;
                        sListToolLengeh.isOK = false;
                        sListToolLengeh.isOverToolLength = false;
                        sListToolLengeh.tool_name = "";
                        sListToolLengeh.tool_ext_length = "";
                        sListToolLengeh.oper_name = "";
                        sListToolLengeh.cutting_length = 0.0;
                        sListToolLengeh.cutting_length_max = 0.0;
                        sListToolLengeh.part_offset = 0.0;

                        operationGroup = OperationAry[i].GetParent(CAMSetup.View.ProgramOrder);
                        if (section_face.ToUpper() == operationGroup.Name.ToUpper())
                        {
                            chk_faca_name = true;

                            //Type operType = OperationAry[i].GetType();
                            //CaxLog.ShowListingWindow("OPERATION_TYPE : " + operType.Name.ToString());

                            //CaxLog.ShowListingWindow("GetStatus : " + OperationAry[i].GetStatus().ToString());
                            if (OperationAry[i].GetStatus() != CAMObject.Status.Complete && OperationAry[i].GetStatus() != CAMObject.Status.Repost)
                            {
                                status = CaxCAM.GenerateToolPath(OperationAry[i].Name);
                                if (!status)
                                {
                                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, OperationAry[i].Name + " Generate 失敗...");
                                    return false;
                                }
                            }

                            //CaxLog.ShowListingWindow("ToString : " + OperationAry[i].ToString());


                            //取得operation
                            sListToolLengeh.oper = OperationAry[i];

                            //取得operation名稱
                            sListToolLengeh.oper_name = OperationAry[i].Name;

                            //取得刀具GROUP
                            operationGroup = OperationAry[i].GetParent(CAMSetup.View.MachineTool);


                            //CaxLog.ShowListingWindow("TOOL_NAME : " + operationGroup.Name.ToString());

                            //GetToolData(operationGroup.Name);

                            //取得刀具名稱
                            string[] MachineToolNameSplitAry = operationGroup.Name.Split('_');
                            if (MachineToolNameSplitAry.Length < 3)
                            {
                                CaxLog.ShowListingWindow("刀具名稱錯誤 : " + operationGroup.Name);
                                return false;
                            }

                            sListToolLengeh.tool_name = MachineToolNameSplitAry[0];
                            sListToolLengeh.tool_ext_length = MachineToolNameSplitAry[2];

                            //CaxLog.ShowListingWindow("tool_ext_length : " + sListToolLengeh.tool_ext_length);

                            //取得切削長度
                            sListToolLengeh.cutting_length = OperationAry[i].GetToolpathCuttingLength();

                            //取得part offset (Gap)
                            double part_offset = 0;
                            CaxCAM.AskPartOffset(out part_offset);
                            sListToolLengeh.part_offset = part_offset;

                            //判斷切削長度是否過長
                            max_length = 0.0;
                            sListToolLengeh.isOK = false;
                            sListToolLengeh.cutting_length_max = 0.0;
                            for (int j = 0; j < cToolCuttingLength.data.Count; j++)
                            {
                                if (cToolCuttingLength.data[j].TOOL_STD_ID.ToUpper() == sListToolLengeh.tool_name.ToUpper())
                                {
                                    for (int k = 0; k < cToolCuttingLength.data[j].HRC_ARRAY.Count; k++)
                                    {
                                        if (cToolCuttingLength.data[j].HRC_ARRAY[k].TOOL_METER > max_length)
                                        {
                                            max_length = cToolCuttingLength.data[j].HRC_ARRAY[k].TOOL_METER;
                                        }

                                        if ((cToolCuttingLength.data[j].HRC_ARRAY[k].TOOL_METER * 1000) > sListToolLengeh.cutting_length)
                                        {
                                            sListToolLengeh.isOK = true;
                                            goto GOTO_ISOK;
                                        }
                                    }
                                }
                            }

                        GOTO_ISOK:

                            //取得最大切削長度 (MES單位為m，所以要*1000 = mm)
                            sListToolLengeh.cutting_length_max = max_length * 1000;

                            bool chk_tool_name = false;
                            for (int j = 0; j < toolStatusAry.Count; j++)
                            {
                                if (sListToolLengeh.tool_name == toolStatusAry[j].tool_name)
                                {
                                    chk_tool_name = true;
                                }
                            }
                            if (!chk_tool_name)
                            {
                                //sToolLengehStatus.isOverToolLength = false;
                                sToolLengehStatus.tool_name = sListToolLengeh.tool_name;
                                sToolLengehStatus.tool_ext_length = sListToolLengeh.tool_ext_length;//20150515 Andy取消這行註解
                                sToolLengehStatus.cutting_length_max = sListToolLengeh.cutting_length_max;
                                toolStatusAry.Add(sToolLengehStatus);
                            }

                            ListToolLengehAry.Add(sListToolLengeh);
                            continue;
                        }

                    }

                }
                CaxPart.Refresh();


                if (!chk_faca_name)
                {
                    UI.GetUI().NXMessageBox.Show("Message", NXMessageBox.DialogType.Error, "Program Order 未找到 " + section_face + " Group!");
                    return false;
                }

                double totalOperLength = 0.0;
                for (int i = 0; i < toolStatusAry.Count; i++)
                {
                    //20150123 
                    // 刀具壽命限制有份兩段
                    // 1，單條operation超出刀具壽命
                    // 2，同一把刀所有的operation超出刀具壽命

                    // 當是整體式刀具，就按現在的規則（1和2都不要滿足）
                    // 如果是捨棄式刀具，需要修改成
                    // 1，單條OPERATION超出刀具壽命 這條還是不變
                    // 2，同一把刀所有的OPERATION超出刀具壽命 這條不需要限制（也就是還是可以出工單）

                    if (toolStatusAry[i].tool_name.ToUpper().IndexOf("I") == 0)
                    {
                        //捨棄式刀具
                        CaxLog.WriteLog("捨棄式刀具 : " + toolStatusAry[i].tool_name);
                        continue;
                    }

                    CaxLog.WriteLog("整體式刀具 : " + toolStatusAry[i].tool_name);

                    totalOperLength = 0.0;
                    for (int j = 0; j < ListToolLengehAry.Count; j++)
                    {
                        if (toolStatusAry[i].tool_name == ListToolLengehAry[j].tool_name &&
                            toolStatusAry[i].tool_ext_length == ListToolLengehAry[j].tool_ext_length)
                        {
                            totalOperLength += ListToolLengehAry[j].cutting_length;
                        }
                    }
                    if (totalOperLength > toolStatusAry[i].cutting_length_max)
                    {
                        for (int j = 0; j < ListToolLengehAry.Count; j++)
                        {
                            if (toolStatusAry[i].tool_name == ListToolLengehAry[j].tool_name)
                            {
                                sListToolLengeh.oper = ListToolLengehAry[j].oper;
                                sListToolLengeh.isOK = ListToolLengehAry[j].isOK;
                                sListToolLengeh.isOverToolLength = true;
                                sListToolLengeh.tool_name = ListToolLengehAry[j].tool_name;
                                sListToolLengeh.oper_name = ListToolLengehAry[j].oper_name;
                                sListToolLengeh.cutting_length = ListToolLengehAry[j].cutting_length;
                                sListToolLengeh.cutting_length_max = ListToolLengehAry[j].cutting_length_max;

                                //2015-03-20 新增
                                sListToolLengeh.part_offset = ListToolLengehAry[j].part_offset;
                                sListToolLengeh.tool_ext_length = ListToolLengehAry[j].tool_ext_length;


                                ListToolLengehAry[j] = sListToolLengeh;
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// 1.取得工件T面轉BO面Z軸偏移的距離
        /// 2.基準角底面到座標原點的距離
        /// 3.基準角長面(距離原點較長的面)到座標原點的距離
        /// 4.基準角短面(距離原點較短的面)到座標原點的距離
        /// </summary>
        /// <param name="sCimAsmCompPart"></param>
        /// <returns></returns>
        private bool GetCsysToRefFaceData()
        {
            sExportWorkTabel.X_OFFSET = "";
            sExportWorkTabel.Y_OFFSET = "";
            sExportWorkTabel.Z_BASE = "";
            sExportWorkTabel.Z_MOVE = "";
            try
            {
                //ExportWorkTabel sExportWorkTabel;
                string attr_value = "";
                //Z_MOVE
                // 20150618 改成取C面到座標原點距離
                Face baseC = null;
                double[] dirC = new double[3];
                for (int i = 0; i < baseCornerAry.Count; i++)
                {
                    try
                    {
                        string attr = baseCornerAry[i].face.GetStringAttribute(CaxDefineParam.ATTR_CIM_REF_FACE);
                        if (attr == "C")
                        {
                            baseC = baseCornerAry[i].face;
                            dirC = baseCornerAry[i].sFaceData.dir;
                            break;
                        }
                    }
                    catch (System.Exception ex)
                    {
                    	continue;
                    }
                }
                if (dirC[0] < -0.9999)
                {
                    sExportWorkTabel.Z_MOVE = minDesignBodyWcs[0].ToString("f4");
                }
                else if (dirC[0] > 0.9999)
                {
                    sExportWorkTabel.Z_MOVE = maxDesignBodyWcs[0].ToString("f4");
                }
                else if (dirC[1] < -0.9999)
                {
                    sExportWorkTabel.Z_MOVE = minDesignBodyWcs[1].ToString("f4");
                }
                else if (dirC[1] > 0.9999)
                {
                    sExportWorkTabel.Z_MOVE = maxDesignBodyWcs[1].ToString("f4");
                }
                else if (dirC[2] < -0.9999)
                {
                    sExportWorkTabel.Z_MOVE = minDesignBodyWcs[2].ToString("f4");
                }
                else if (dirC[2] > 0.9999)
                {
                    sExportWorkTabel.Z_MOVE = maxDesignBodyWcs[2].ToString("f4");
                }
                else
                {
                    sExportWorkTabel.Z_MOVE = "";
                }
//                 try
//                 {
//                     attr_value = "";
//                     attr_value = displayPart.GetStringAttribute(CaxDefineParam.ATTR_CIM_Z_MOVE);
//                 }
//                 catch (System.Exception ex)
//                 {
//                     attr_value = "";
//                 }
//                 if (attr_value == "")
//                 {
//                     try
//                     {
//                         attr_value = "";
//                         attr_value = sCimAsmCompPart.design.part.GetStringAttribute(CaxDefineParam.ATTR_CIM_Z_MOVE);
//                     }
//                     catch (System.Exception ex)
//                     {
//                         attr_value = "";
//                     }
//                 }
//                 sExportWorkTabel.Z_MOVE = attr_value;

                //X_OFFSET
                try
                {
                    attr_value = "";
                    attr_value = displayPart.GetStringAttribute(CaxDefineParam.ATTR_CIM_FACE_X_OFFSET);
                }
                catch (System.Exception ex)
                {
                    attr_value = "";
                }
                if (attr_value == "")
                {
                    try
                    {
                        attr_value = "";
                        attr_value = sCimAsmCompPart.design.part.GetStringAttribute(CaxDefineParam.ATTR_CIM_FACE_X_OFFSET);
                    }
                    catch (System.Exception ex)
                    {
                        attr_value = "";
                    }
                }
                sExportWorkTabel.X_OFFSET = attr_value;

                //Y_OFFSET
                try
                {
                    attr_value = "";
                    attr_value = displayPart.GetStringAttribute(CaxDefineParam.ATTR_CIM_FACE_Y_OFFSET);
                }
                catch (System.Exception ex)
                {
                    attr_value = "";
                }
                if (attr_value == "")
                {
                    try
                    {
                        attr_value = "";
                        attr_value = sCimAsmCompPart.design.part.GetStringAttribute(CaxDefineParam.ATTR_CIM_FACE_Y_OFFSET);
                    }
                    catch (System.Exception ex)
                    {
                        attr_value = "";
                    }
                }
                sExportWorkTabel.Y_OFFSET = attr_value;

                //Z_BASE
                try
                {
                    attr_value = "";
                    attr_value = displayPart.GetStringAttribute(CaxDefineParam.ATTR_CIM_Z_BASE);
                }
                catch (System.Exception ex)
                {
                    attr_value = "";
                }
                if (attr_value == "")
                {
                    try
                    {
                        attr_value = "";
                        attr_value = sCimAsmCompPart.design.part.GetStringAttribute(CaxDefineParam.ATTR_CIM_Z_BASE);
                    }
                    catch (System.Exception ex)
                    {
                        attr_value = "";
                    }
                }
                sExportWorkTabel.Z_BASE = attr_value;

            }
            catch (System.Exception ex)
            {
                return false;
            }
            return true;
        }

        private bool GetElecPartNoNote()
        {
            try
            {
                string baseNoteValue = "";
                BaseNote[] noteAry = displayPart.Notes.ToArray();
                for (int i = 0; i < noteAry.Length; i++)
                {
                    baseNoteValue = "";

                    try
                    {
                        baseNoteValue = noteAry[i].GetStringAttribute("ELEC_PART_NO");
                    }
                    catch (System.Exception ex)
                    {
                        baseNoteValue = "";
                    }
                    if (baseNoteValue == "1")
                    {
                        elecPartNoNote = noteAry[i];
                    }
                }
            }
            catch (System.Exception ex)
            {
                return false;
            }
            return true;
        }

        // 讀取配置檔
        public static bool ReadJsonData(string JsonStyleLoadPath, out ConfigData JsonRead)
        {
            JsonRead = new ConfigData();
            try
            {
                bool status;
                // 檢查檔案是否存在
                if (!System.IO.File.Exists(JsonStyleLoadPath))
                {
                    CaxLog.ShowListingWindow("配置檔不存在：" + JsonStyleLoadPath);
                    return false;
                }
                string jsonText;
                status = CaxFile.ReadFileDataUTF8(JsonStyleLoadPath, out jsonText);
                if (!status)
                {
                    CaxLog.ShowListingWindow("配置檔讀取失敗：" + JsonStyleLoadPath);
                    return false;
                }
                JsonRead = Newtonsoft.Json.JsonConvert.DeserializeObject<ConfigData>(jsonText);
            }
            catch (System.Exception ex)
            {
                //CaxLog.ShowListingWindow(ex.Message);
                return false;
            }
            return true;
        }

    }
}
