﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NXOpen.CAM;

namespace ETableWork
{
    class Class002_MyClass
    {
    }

    public struct ExportWorkTabel
    {
        public string Z_MOVE;   // 工件T面轉BO面Z軸偏移的距離
        public string Z_BASE;   // 基準角底面到座標原點的距離
        public string X_OFFSET; // 基準角長面(距離原點較長的面)到座標原點的距離
        public string Y_OFFSET; // 基準角短面(距離原點較短的面)到座標原點的距離
    }

    public struct ListToolLengeh
    {
        public Operation oper;
        public bool isOK;
        public bool isOverToolLength;
        public string tool_name;
        public string tool_ext_length;
        public string oper_name;
        public double cutting_length;
        public double cutting_length_max;
        public double part_offset;
    }

    public struct ToolLengehStatus
    {
        //public bool isOverToolLength;
        public string tool_name;
        public string tool_ext_length;
        public double cutting_length_max;
    }

    public struct WorkPieceElecTaskKey
    {
        public string MOLD_NO;
        public string DES_VER_NO;
        public string WORK_NO;
        public string PART_NO;
        public string MFC_NO;
        public string MFC_TASK_NO;
        public string TASK_NO;
        public string MAC_MODEL_NO;
        public string TASK_SRNO;
    }
    // 配置檔ETable.txt
    public class ConfigData
    {
        public string companyName { get; set; }
        public string hasCMM { get; set; }
        public string hasMultiFixture { get; set; }
    }



}
